import java.util.*;
public class Main {

    public static int largestRectangleArea(int[] heights) {
        if (heights == null || heights.length == 0) {
            return 0;
        }

        int maxArea = 0;
        Stack<Integer> stack = new Stack<>();

        for (int i = 0; i <= heights.length; i++) {
            while (!stack.isEmpty() && (i == heights.length || heights[i] < heights[stack.peek()])) {
                int height = heights[stack.pop()];
                int width = stack.isEmpty() ? i : i - stack.peek() - 1;
                maxArea = Math.max(maxArea, height * width);
            }
            stack.push(i);
        }

        return maxArea;
    }

    public static void main(String[] args) {
        Scanner ps = new Scanner(System.in);
        String[] s = ps.next().replace("]","").replace("[","").split(",");
        int a[] = new int[s.length];
        for(int i = 0 ;i<s.length;i++){
            a[i] = Integer.parseInt(s[i]);
        }
        System.out.println(largestRectangleArea(a));
    }
}
